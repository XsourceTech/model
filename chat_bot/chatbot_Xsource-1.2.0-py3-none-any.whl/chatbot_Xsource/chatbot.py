########### Libraries ###########
# internal imports
from chatbot_Xsource.llm_manager import GPTManager
from chatbot_Xsource.prompt_template import Prompt

########### Class ###########


class Chatbot:
    def __init__(self, memory=[]):
        self._gpt_manager = GPTManager()
        self._prompt_manager = Prompt()
        self._memories = memory

    def get_memory(self):
        return self._memories

    def set_memory(self, memory):
        self._memories.append(memory)

    def generate_response_for_general_information(self, user_message: str) -> str:

        # update history with user message
        self._memories.append({"role": "user", "content": user_message})

        # get the system prompt
        system_message = self._prompt_manager.get_general_information_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return response

    def generate_response_for_major(self, user_message: str) -> str:

        # update history with user message
        self._memories.append({"role": "user", "content": user_message})

        # get the system prompt
        system_message = self._prompt_manager.get_major_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return response

    def generate_response_for_field(self, user_message: str) -> str:

        # update history with user message
        self._memories.append({"role": "user", "content": user_message})

        # get the system prompt
        system_message = self._prompt_manager.get_field_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return response

    def generate_response_for_topic(self, user_message: str) -> str:

        # update history with user message
        self._memories.append({"role": "user", "content": user_message})

        # get the system prompt
        system_message = self._prompt_manager.get_topic_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return response

    def generate_response_for_title(self, user_message: str) -> str:

        # update history with user message
        self._memories.append({"role": "user", "content": user_message})

        # get the system prompt
        system_message = self._prompt_manager.get_title_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return response

    def get_major(self) -> str:
        # get the system prompt
        system_message = self._prompt_manager.get_summarize_major_system_prompt()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        return response

    def get_field(self) -> str:
        # get the system prompt
        system_message = self._prompt_manager.get_summarize_field_system_prompt()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        return response

    def get_topic(self) -> str:
        # get the system prompt
        system_message = self._prompt_manager.get_summarize_topic_system_prompt()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        return response

    def get_title(self) -> str:
        # get the system prompt
        system_message = self._prompt_manager.get_summarize_title_system_prompt()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        return response

    def get_summary(self) -> str:
        # get the system prompt
        system_message = self._prompt_manager.get_summarize_information_system_prompt()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        return response
