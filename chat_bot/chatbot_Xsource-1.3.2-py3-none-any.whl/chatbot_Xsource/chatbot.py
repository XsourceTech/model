########### Libraries ###########
# internal imports
from chatbot_Xsource.llm_manager import GPTManager
from chatbot_Xsource.prompt_template import Prompt
from chatbot_Xsource.prompt_template_abstract import PromptAbstract

########### Class ###########


class Chatbot:
    def __init__(self, memory=[]):
        self._gpt_manager = GPTManager()
        self._prompt_manager = Prompt()
        self._memories = memory

    def get_memory(self):
        return self._memories

    def set_memory(self, memory):
        self._memories.append(memory)

    def generate_response_for_major(self):

        # get the system prompt
        system_message = self._prompt_manager.get_major_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def generate_response_for_field(self):

        # get the system prompt
        system_message = self._prompt_manager.get_field_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def generate_response_for_topic(self):

        # get the system prompt
        system_message = self._prompt_manager.get_topic_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def generate_response_for_title(self):

        # get the system prompt
        system_message = self._prompt_manager.get_title_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def generate_response_for_number(self):

        # get the system prompt
        system_message = self._prompt_manager.get_number_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def get_summary(self) -> str:

        system_message = self._prompt_manager.get_summarize_information_system_prompt()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        return response


class Chatbot_Abstract:
    def __init__(self, memory=[]):
        self._gpt_manager = GPTManager()
        self._prompt_manager = PromptAbstract()
        self._memories = memory

    def get_memory(self):
        return self._memories

    def set_memory(self, memory):
        self._memories.append(memory)

    def generate_response_for_motivation(self):

        # get the system prompt
        system_message = self._prompt_manager.get_motivation_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def generate_response_for_question(self):

        # get the system prompt
        system_message = self._prompt_manager.get_question_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def generate_response_for_method(self):

        # get the system prompt
        system_message = self._prompt_manager.get_method_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def generate_response_for_conclusion(self):

        # get the system prompt
        system_message = self._prompt_manager.get_conclusion_system_prompt_chinese()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        # update history with system message
        self._memories.append({"role": "assistant", "content": response})

        return self.get_memory()

    def get_summary(self) -> str:

        system_message = self._prompt_manager.get_summarize_abstract_system_prompt()

        # get the response from the GPT model
        response = self._gpt_manager.get_response(
            self._memories, system_message, model_generation="gpt-4o-mini")

        return response
